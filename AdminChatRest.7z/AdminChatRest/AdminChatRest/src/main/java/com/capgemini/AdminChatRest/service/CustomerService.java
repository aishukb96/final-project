package com.capgemini.AdminChatRest.service;

import java.util.List;

import com.capgemini.AdminChatRest.model.Customer;


public interface CustomerService {
	public List<Customer> getAll();

}
