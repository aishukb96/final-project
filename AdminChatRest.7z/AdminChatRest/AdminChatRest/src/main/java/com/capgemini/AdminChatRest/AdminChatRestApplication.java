package com.capgemini.AdminChatRest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdminChatRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdminChatRestApplication.class, args);
	}
}
