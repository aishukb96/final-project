package com.capgemini.AdminChatRest.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Customer {
@Id
@GeneratedValue
private int custId;
private String cname;
private boolean cisactive;
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public boolean isCisactive() {
	return cisactive;
}
public void setCisactive(boolean cisactive) {
	this.cisactive = cisactive;
}
public Customer(String cname, boolean cisactive) {
	super();
	this.cname = cname;
	this.cisactive = cisactive;
}
public Customer() {
	super();
}
public int getCustId() {
	return custId;
}
public void setCustId(int custId) {
	this.custId = custId;
}


}
