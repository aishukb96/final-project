package com.capgemini.AdminChatRest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.AdminChatRest.model.Customer;
import com.capgemini.AdminChatRest.service.CustomerService;

@RestController
@RequestMapping("/api/v1")
public class AdminChatRestController {
	@Autowired
	private CustomerService customerService;
	
	@GetMapping("/")
	public ResponseEntity<List<Customer>> getAllCustomers()
	{
		List<Customer> customer=customerService.getAll();
		return new ResponseEntity<List<Customer>>(customer,HttpStatus.OK);
	}
}
