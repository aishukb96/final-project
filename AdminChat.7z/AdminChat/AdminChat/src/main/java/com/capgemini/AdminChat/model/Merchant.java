package com.capgemini.AdminChat.model;




public class Merchant {

private int merchantId;	
private String mname;
private boolean isactive;
public String getMname() {
	return mname;
}
public void setMname(String mname) {
	this.mname = mname;
}
public boolean isIsactive() {
	return isactive;
}
public void setIsactive(boolean isactive) {
	this.isactive = isactive;
}
public Merchant(String mname, boolean isactive) {
	super();
	this.mname = mname;
	this.isactive = isactive;
}
public Merchant() {
	super();
}
public int getMerchantId() {
	return merchantId;
}
public void setMerchantId(int merchantId) {
	this.merchantId = merchantId;
}


}
