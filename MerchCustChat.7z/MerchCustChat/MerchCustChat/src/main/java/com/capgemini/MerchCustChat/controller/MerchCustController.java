package com.capgemini.MerchCustChat.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MerchCustController {
	 @RequestMapping("/")
	    public String index(HttpServletRequest request, Model model) {
	        String username = (String) request.getSession().getAttribute("username");
	 
	        
	        model.addAttribute("username", username);
	 
	        return "MerchantChat";
	    }
	 
	 @RequestMapping("/customer")
	    public String index1(HttpServletRequest request, Model model) {
	        String username = (String) request.getSession().getAttribute("username");
	 
	        
	        model.addAttribute("username", username);
	 
	        return "CustomerChat";
	    }
}
